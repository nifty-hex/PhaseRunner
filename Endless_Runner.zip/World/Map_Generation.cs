﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map_Generation : MonoBehaviour {

    public float player_x_pos = 0;
    public float map_x_gap; //21-25
    public float map_x_offset;
    public float map_y_pos; //0-4
    public float map_y_offset;

    public GameObject Platform_1;
    public GameObject Platform_2;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.x > player_x_pos && transform.position.x > 0)
        {
            
            map_x_gap = Random.Range(20.5f, 24.5f);
            map_y_pos = Random.Range(0f, 3.5f);
            player_x_pos += map_x_gap;
            Instantiate(Platform_1, new Vector3(player_x_pos + map_x_offset, map_y_pos + map_y_offset, 0), Quaternion.identity);
            //Debug.Log("Spawning Platform: " + "x:" + player_x_pos + map_x_offset + "| y:" + map_y_pos + map_y_offset);
        }
	}
}
