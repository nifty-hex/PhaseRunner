﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_shoot : MonoBehaviour {

    public GameObject bullet;
    public Rigidbody2D bullet_rb;
    public float speed;
    public Vector3 mouse_direction;

	// Use this for initialization
	void Start () {
        mouse_direction.z = 0.0f;
        bullet_rb = GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            mouse_direction = Camera.main.ScreenToWorldPoint(mouse_direction);
            mouse_direction -= transform.position;

            Instantiate(bullet, transform.position, Quaternion.Euler(new Vector3(0, 0, 0)));
            bullet_rb.velocity = new Vector2(mouse_direction.x * speed, mouse_direction.y * speed);
        }
    }
}
