﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slow_Time : MonoBehaviour {

    public float time_scale_tracker;
    public float time_slowness;
    public float time_fix_mul;
    public float time_restore_speed;
    public float time_loss_speed;
    public float time_slow_limit;
    public float normal_time_slow_limit;
    public bool over_limit;
    
	// Use this for initialization
	void Start () {
        normal_time_slow_limit = time_slow_limit;
    }
	
	// Update is called once per frame
	void Update () {
        time_scale_tracker = Time.timeScale;
        if (Input.GetKey(KeyCode.LeftShift) && time_slow_limit > 0 && over_limit == false)
        {
            time_slow_limit -= (Time.deltaTime * time_loss_speed);
            if (Time.timeScale > time_slowness)
                Time.timeScale -= (Time.deltaTime * time_fix_mul);
        }
        else
        {
            if (Time.timeScale < 1.0f)
                Time.timeScale += (Time.deltaTime * time_fix_mul);
        }
        if (time_slow_limit < normal_time_slow_limit)
            time_slow_limit += Time.deltaTime * time_restore_speed;
        if (time_slow_limit < 0)
            over_limit = true;
        if (time_slow_limit >= normal_time_slow_limit)
            over_limit = false;
    }
}
