﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour {

    public float life_time;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        life_time -= Time.deltaTime;
        if (life_time < 0)
        {
            Destroy(this.gameObject);
        }
	}
}
