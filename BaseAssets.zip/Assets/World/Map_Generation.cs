﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map_Generation : MonoBehaviour {

    public float player_x_pos = 0;
    public float player_x_offset;
    public float map_x_gap; //21-25
    public float map_x_offset;
    public float map_y_pos; //0-4
    public float map_y_offset;

    public int obstacles_freq;
    public float obstacles_x_offset_min;
    public float obstacles_x_offset_max;
    public float obstacles_y_offset;

    public GameObject Platform_1;
    public GameObject Platform_2;
    public GameObject obstacle_1;
    public GameObject obstacle_2;
    public GameObject Enemy_1;

    public int map_id;

    // Use this for initialization
    void Start () {
        Debug.Log("Version 0.0.166");
    }
	
	// Update is called once per frame
	void Update () {
        //Platforms
		if (transform.position.x + player_x_offset > player_x_pos && transform.position.x > 0)
        {
            map_x_gap = Random.Range(20.5f, 24.5f);
            map_y_pos = Random.Range(0f, 3.1f);
            player_x_pos += map_x_gap;
            map_id = Random.Range(0, 6);
            if (map_id >= 0 && map_id <= 4)
            {
                Instantiate(Platform_1, new Vector3(player_x_pos + map_x_offset, map_y_pos + map_y_offset, 0), Quaternion.identity);
            }
            else
            {
                Instantiate(Platform_2, new Vector3(player_x_pos + map_x_offset, map_y_pos + map_y_offset, 0), Quaternion.identity);
            }
        }

        //Obstacles
        if (Random.Range(0, obstacles_freq) == 0)
        {
            Debug.Log("Crates");
            Instantiate(obstacle_1, new Vector3(transform.position.x + Random.Range(obstacles_x_offset_min, obstacles_x_offset_max), 
                map_y_pos + obstacles_y_offset, 0), Quaternion.identity);
        }

    }
}
